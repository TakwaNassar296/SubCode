<?php
    $uniqueActionId = $getUniqueActionId();

    $statePath = $getStatePath();

    $shouldRefresh = $shouldRefresh();

    $data = $this->getMountedActionSchema()->getState();

    $tableViewName = \AlperenErsoy\FilamentExport\FilamentExport::TABLE_VIEW_NAME;

    $shouldPrint = is_array($data) && array_key_exists($tableViewName, $data) && $data[$tableViewName] == 'print-' . $uniqueActionId;

    $printContent = $shouldPrint ? $getPrintHTML() : '';
?>

<input id="<?php echo e($statePath); ?>" type="hidden" <?php echo e($applyStateBindingModifiers('wire:model')); ?>="<?php echo e($statePath); ?>">

<?php if (isset($component)) { $__componentOriginal0942a211c37469064369f887ae8d1cef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0942a211c37469064369f887ae8d1cef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.modal.index','data' => ['id' => 'preview-modal','width' => '7xl','displayClasses' => 'block','darkMode' => config('filament.dark_mode'),'xInit' => '$wire.$on(\'open-preview-modal-'.e($uniqueActionId).'\', function() {
        $set(\''.e($tableViewName).'\', \''.e(uniqid()).'\');
        isOpen = true;
    });
    
    $wire.$on(\'close-preview-modal-'.e($uniqueActionId).'\', () => { isOpen = false; });
    
    if ('.e($shouldRefresh ? 'true' : 'false').') {
        $wire.dispatch(\'close-preview-modal-'.e($uniqueActionId).'\');

        $set(\''.e($tableViewName).'\', \''.e(uniqid()).'\');
        
        $wire.dispatch(\'open-preview-modal-'.e($uniqueActionId).'\');
    }

    if ('.e($shouldPrint ? 'true' : 'false').') {
        window.printHTML(`'.$printContent.'`, \''.e($statePath).'\', \''.e($uniqueActionId).'\', $set);
    }
    ','xOn:keydown.window.escape.capture' => 'isOpen = false','heading' => $getPreviewModalHeading()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'preview-modal','width' => '7xl','display-classes' => 'block','dark-mode' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(config('filament.dark_mode')),'x-init' => '$wire.$on(\'open-preview-modal-'.e($uniqueActionId).'\', function() {
        $set(\''.e($tableViewName).'\', \''.e(uniqid()).'\');
        isOpen = true;
    });
    
    $wire.$on(\'close-preview-modal-'.e($uniqueActionId).'\', () => { isOpen = false; });
    
    if ('.e($shouldRefresh ? 'true' : 'false').') {
        $wire.dispatch(\'close-preview-modal-'.e($uniqueActionId).'\');

        $set(\''.e($tableViewName).'\', \''.e(uniqid()).'\');
        
        $wire.dispatch(\'open-preview-modal-'.e($uniqueActionId).'\');
    }

    if ('.e($shouldPrint ? 'true' : 'false').') {
        window.printHTML(`'.$printContent.'`, \''.e($statePath).'\', \''.e($uniqueActionId).'\', $set);
    }
    ','x-on:keydown.window.escape.capture' => 'isOpen = false','heading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getPreviewModalHeading())]); ?>
    <div class="preview-table-wrapper space-y-4 fi-ta-ctn">
        <table class="preview-table" x-init="$wire.$on('print-table-<?php echo e($uniqueActionId); ?>', function() {
            $set('<?php echo e($tableViewName); ?>', 'print-<?php echo e($uniqueActionId); ?>');
        })">
            <tr class="dark:border-gray-700">
                <?php $__currentLoopData = $getAllTableColumns(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="dark:border-gray-700">
                        <?php echo e($column->getLabel()); ?>

                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <?php $__currentLoopData = $getRows(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="dark:border-gray-700">
                    <?php $__currentLoopData = $getAllTableColumns(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="dark:border-gray-700">
                            <?php echo e($row[$column->getName()]); ?>

                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div>
            <?php if (isset($component)) { $__componentOriginal0c287a00f29f01c8f977078ff96faed4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0c287a00f29f01c8f977078ff96faed4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.pagination.index','data' => ['paginator' => $getRows(),'pageOptions' => $this->getTable()->getPaginationPageOptions(),'class' => 'preview-table-pagination px-3 py-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getRows()),'page-options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($this->getTable()->getPaginationPageOptions()),'class' => 'preview-table-pagination px-3 py-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0c287a00f29f01c8f977078ff96faed4)): ?>
<?php $attributes = $__attributesOriginal0c287a00f29f01c8f977078ff96faed4; ?>
<?php unset($__attributesOriginal0c287a00f29f01c8f977078ff96faed4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c287a00f29f01c8f977078ff96faed4)): ?>
<?php $component = $__componentOriginal0c287a00f29f01c8f977078ff96faed4; ?>
<?php unset($__componentOriginal0c287a00f29f01c8f977078ff96faed4); ?>
<?php endif; ?>
        </div>
    </div>
     <?php $__env->slot('footer', null, []); ?> 
        <?php $__currentLoopData = $getFooterActions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($action); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $attributes = $__attributesOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__attributesOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $component = $__componentOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__componentOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\subcode\resources\views\vendor\filament-export\components\table_view.blade.php ENDPATH**/ ?>