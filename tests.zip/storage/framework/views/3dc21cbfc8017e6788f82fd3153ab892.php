<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('language-switch-component', []);

$__html = app('livewire')->mount($__name, $__params, 'fls-in-panels', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?><?php /**PATH C:\xampp\htdocs\subcode\storage\framework\views/0a5cc43e3ce9da56eefe6c41d9cb9d99.blade.php ENDPATH**/ ?>