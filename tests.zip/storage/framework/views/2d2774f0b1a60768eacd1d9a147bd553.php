<h2
    <?php echo e($attributes->class(['fi-section-header-heading'])); ?>

>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH C:\xampp\htdocs\subcode\vendor\filament\support\resources\views\components\section\heading.blade.php ENDPATH**/ ?>