<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.activity-logs.pages.create-activity-log' => 'App\\Filament\\Resources\\ActivityLogs\\Pages\\CreateActivityLog',
    'app.filament.resources.activity-logs.pages.edit-activity-log' => 'App\\Filament\\Resources\\ActivityLogs\\Pages\\EditActivityLog',
    'app.filament.resources.activity-logs.pages.list-activity-logs' => 'App\\Filament\\Resources\\ActivityLogs\\Pages\\ListActivityLogs',
    'app.filament.resources.activity-logs.pages.view-activity-log' => 'App\\Filament\\Resources\\ActivityLogs\\Pages\\ViewActivityLog',
    'app.filament.resources.daily-work-logs.pages.create-daily-work-log' => 'App\\Filament\\Resources\\DailyWorkLogs\\Pages\\CreateDailyWorkLog',
    'app.filament.resources.daily-work-logs.pages.edit-daily-work-log' => 'App\\Filament\\Resources\\DailyWorkLogs\\Pages\\EditDailyWorkLog',
    'app.filament.resources.daily-work-logs.pages.list-daily-work-logs' => 'App\\Filament\\Resources\\DailyWorkLogs\\Pages\\ListDailyWorkLogs',
    'app.filament.resources.daily-work-logs.pages.view-daily-work-log' => 'App\\Filament\\Resources\\DailyWorkLogs\\Pages\\ViewDailyWorkLog',
    'app.filament.resources.problems.pages.create-problem' => 'App\\Filament\\Resources\\Problems\\Pages\\CreateProblem',
    'app.filament.resources.problems.pages.edit-problem' => 'App\\Filament\\Resources\\Problems\\Pages\\EditProblem',
    'app.filament.resources.problems.pages.list-problems' => 'App\\Filament\\Resources\\Problems\\Pages\\ListProblems',
    'app.filament.resources.problems.pages.view-problem' => 'App\\Filament\\Resources\\Problems\\Pages\\ViewProblem',
    'app.filament.resources.projects.pages.create-project' => 'App\\Filament\\Resources\\Projects\\Pages\\CreateProject',
    'app.filament.resources.projects.pages.edit-project' => 'App\\Filament\\Resources\\Projects\\Pages\\EditProject',
    'app.filament.resources.projects.pages.list-projects' => 'App\\Filament\\Resources\\Projects\\Pages\\ListProjects',
    'app.filament.resources.projects.pages.view-project' => 'App\\Filament\\Resources\\Projects\\Pages\\ViewProject',
    'app.filament.resources.task-reviews.pages.create-task-review' => 'App\\Filament\\Resources\\TaskReviews\\Pages\\CreateTaskReview',
    'app.filament.resources.task-reviews.pages.edit-task-review' => 'App\\Filament\\Resources\\TaskReviews\\Pages\\EditTaskReview',
    'app.filament.resources.task-reviews.pages.list-task-reviews' => 'App\\Filament\\Resources\\TaskReviews\\Pages\\ListTaskReviews',
    'app.filament.resources.task-reviews.pages.view-task-review' => 'App\\Filament\\Resources\\TaskReviews\\Pages\\ViewTaskReview',
    'app.filament.resources.tasks.pages.create-task' => 'App\\Filament\\Resources\\Tasks\\Pages\\CreateTask',
    'app.filament.resources.tasks.pages.edit-task' => 'App\\Filament\\Resources\\Tasks\\Pages\\EditTask',
    'app.filament.resources.tasks.pages.list-tasks' => 'App\\Filament\\Resources\\Tasks\\Pages\\ListTasks',
    'app.filament.resources.tasks.pages.view-task' => 'App\\Filament\\Resources\\Tasks\\Pages\\ViewTask',
    'app.filament.resources.users.pages.create-user' => 'App\\Filament\\Resources\\Users\\Pages\\CreateUser',
    'app.filament.resources.users.pages.edit-user' => 'App\\Filament\\Resources\\Users\\Pages\\EditUser',
    'app.filament.resources.users.pages.list-users' => 'App\\Filament\\Resources\\Users\\Pages\\ListUsers',
    'app.filament.resources.users.pages.view-user' => 'App\\Filament\\Resources\\Users\\Pages\\ViewUser',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'app.filament.widgets.problem-status-chart' => 'App\\Filament\\Widgets\\ProblemStatusChart',
    'app.filament.widgets.stats-overview' => 'App\\Filament\\Widgets\\StatsOverview',
    'app.filament.widgets.task-status-chart' => 'App\\Filament\\Widgets\\TaskStatusChart',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.auth.pages.edit-profile' => 'Filament\\Auth\\Pages\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.livewire.sidebar' => 'Filament\\Livewire\\Sidebar',
    'filament.livewire.simple-user-menu' => 'Filament\\Livewire\\SimpleUserMenu',
    'filament.livewire.topbar' => 'Filament\\Livewire\\Topbar',
    'filament.auth.pages.login' => 'Filament\\Auth\\Pages\\Login',
    'bezhan-salleh.filament-shield.resources.roles.pages.list-roles' => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\ListRoles',
    'bezhan-salleh.filament-shield.resources.roles.pages.create-role' => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\CreateRole',
    'bezhan-salleh.filament-shield.resources.roles.pages.view-role' => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\ViewRole',
    'bezhan-salleh.filament-shield.resources.roles.pages.edit-role' => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\Pages\\EditRole',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\subcode\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    0 => 'BezhanSalleh\\FilamentShield\\Resources\\Roles\\RoleResource',
    'C:\\xampp\\htdocs\\subcode\\app\\Filament\\Resources\\ActivityLogs\\ActivityLogResource.php' => 'App\\Filament\\Resources\\ActivityLogs\\ActivityLogResource',
    'C:\\xampp\\htdocs\\subcode\\app\\Filament\\Resources\\DailyWorkLogs\\DailyWorkLogResource.php' => 'App\\Filament\\Resources\\DailyWorkLogs\\DailyWorkLogResource',
    'C:\\xampp\\htdocs\\subcode\\app\\Filament\\Resources\\Problems\\ProblemResource.php' => 'App\\Filament\\Resources\\Problems\\ProblemResource',
    'C:\\xampp\\htdocs\\subcode\\app\\Filament\\Resources\\Projects\\ProjectResource.php' => 'App\\Filament\\Resources\\Projects\\ProjectResource',
    'C:\\xampp\\htdocs\\subcode\\app\\Filament\\Resources\\TaskReviews\\TaskReviewResource.php' => 'App\\Filament\\Resources\\TaskReviews\\TaskReviewResource',
    'C:\\xampp\\htdocs\\subcode\\app\\Filament\\Resources\\Tasks\\TaskResource.php' => 'App\\Filament\\Resources\\Tasks\\TaskResource',
    'C:\\xampp\\htdocs\\subcode\\app\\Filament\\Resources\\Users\\UserResource.php' => 'App\\Filament\\Resources\\Users\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\subcode\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'C:\\xampp\\htdocs\\subcode\\app\\Filament\\Widgets\\ProblemStatusChart.php' => 'App\\Filament\\Widgets\\ProblemStatusChart',
    'C:\\xampp\\htdocs\\subcode\\app\\Filament\\Widgets\\StatsOverview.php' => 'App\\Filament\\Widgets\\StatsOverview',
    'C:\\xampp\\htdocs\\subcode\\app\\Filament\\Widgets\\TaskStatusChart.php' => 'App\\Filament\\Widgets\\TaskStatusChart',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\subcode\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);